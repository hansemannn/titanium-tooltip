//
//  TiTooltip.h
//  titanium-tooltip
//
//  Created by Your Name
//  Copyright (c) 2019 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TiTooltip.
FOUNDATION_EXPORT double TiTooltipVersionNumber;

//! Project version string for TiTooltip.
FOUNDATION_EXPORT const unsigned char TiTooltipVersionString[];

#import "TiTooltipModuleAssets.h"
